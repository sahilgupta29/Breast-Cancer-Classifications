# Breast-Cancer-Prediction-Model-using-Machine-Learning
This project implements a machine learning model to predict whether a breast tumor is malignant or benign based on a set of features extracted from the digital images of breast mass
